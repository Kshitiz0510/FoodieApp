export interface User {
    name: string;
    location:string;
    ratinf:string;
  }